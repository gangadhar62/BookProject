﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Book
{
    class Books
    {
        public int Id;
        public string bookName, authorName, descriptionOfBook;
        public float price;

        public Books(int id, string bookName, string authorName, string descriptionOfBook, float price)
        {
            this.Id = id;
            this.bookName = bookName;
            this.authorName = authorName;
            this.descriptionOfBook = descriptionOfBook;
            this.price = price;
        }

        public override string ToString()
        {
            return $" BookId : {Id}; Books Name : {bookName}; Author Name : {authorName}; Book Description : {descriptionOfBook}; price:{price};";
        }
    }
    internal class Program
    {
        static void displayBook(List<Books>arr)
        {
            foreach (Books item in arr)
            {
                Console.WriteLine(item);
            }
        }
        static void Main(string[] args)
        {
            List<Books> bookList = new List<Books>{

                new Books(1, "Twilight","Stephenie Meyer","Hello Twilight", 250),
                new Books(2, "New Moon","Stephenie Meyer","Hello New Moon", 300),
                new Books(3, "Eclipse","Stephenie Meyer","Hello Eclipse", 350),
                new Books(4, "Breaking Dawn","Stephenie Meyer","Hello Breaking Dawn", 450),
                new Books(5, "Breaking Dawn 2","Stephenie Meyer","Hello Breaking Dawn 2", 500),

            };
            displayBook(bookList);

            Console.WriteLine("Press 1 : To Edit ");
            Console.WriteLine("Press 2 : To Delete");
            Console.WriteLine("Press 3 : To Add ");
            Console.WriteLine("Press 4 : To Expose discription");
            Console.WriteLine("press 5 : To Display");

            int num = 0;
            Console.WriteLine();
            Console.WriteLine("Choose the number u want");
            num = int.Parse(Console.ReadLine());

            switch (num)
            {
                case 1:

                    Console.WriteLine("Press 1 : To Change Book name");
                    Console.WriteLine("Press 2 : To Change Book author");
                    Console.WriteLine("Press 3 : To ChangeBook description");
                    Console.WriteLine("Press 4 : To Change Book price");

                    Console.WriteLine("Give the book id");
                    int bookId = int.Parse(Console.ReadLine());
                    int bookindex = 0;
                    foreach (Books item in bookList)
                    {
                        if (item.Id == bookId)
                        {
                            bookindex = bookList.IndexOf(item);

                        }
                    }
                    Console.WriteLine("Choose the num for particular action");
                    int selectedNum = int.Parse(Console.ReadLine());

                    switch (selectedNum)
                    {
                        case 1:
                            Console.WriteLine("Give the book name");
                            string nameOfBook = Console.ReadLine();

                            bookList[bookindex].bookName = nameOfBook;

                            break;
                         case 2:
                            Console.WriteLine("Give the Author name");
                            string authorOfBook = Console.ReadLine();

                            bookList[bookindex].authorName = authorOfBook;

                            break;
                         case 3:
                            Console.WriteLine("Give the description");
                            string descriptionOfBook = Console.ReadLine();

                            bookList[bookindex].descriptionOfBook = descriptionOfBook;

                            break;
                        case 4:
                            Console.WriteLine("Give the price");
                    
                            float priceOfBook = float.Parse(Console.ReadLine());

                            bookList[bookindex].price = priceOfBook;

                            break;

                    }

                    Console.WriteLine("Updated book details");
                    Console.WriteLine(bookList[bookindex]);
                    break;
                case 2:

                    Console.WriteLine("Enter the BookId to delete");
                    int deleteId = int.Parse(Console.ReadLine());
                    int mainIndex = 0;
                    foreach (Books item in bookList)
                    {
                        if (item.Id == deleteId)
                        {
                            mainIndex = bookList.IndexOf(item);

                        }
                    }
                    bookList.RemoveAt(mainIndex);
                    displayBook(bookList);

                    break;
                case 3:

                    Console.WriteLine("No.of books to add");
                    int n = int.Parse(Console.ReadLine());

                    for (int i = 1; i <= n; i++)
                    {
                        Console.WriteLine("Give the book  Details");
                        Console.WriteLine("Enter the Bookname");
                        string bookName = Console.ReadLine();

                        Console.WriteLine("Enter the Author name");
                        string authorName = Console.ReadLine();

                        Console.WriteLine("Enter the Description");
                        string descriptionOfBook = Console.ReadLine();

                        Console.WriteLine("Enter the Price");
                        float price;
                        bool result = Single.TryParse(Console.ReadLine(), out price);

                        if (result)
                        {
                            bookList.Add(new Books(bookList.Count + i, bookName, authorName, descriptionOfBook, price));

                        }
                    }
                    displayBook(bookList);
                    break;

                case 4:

                    Console.WriteLine("Give the bookId to highlight that particular description");
                    int askId = int.Parse(Console.ReadLine());
                    int subIndex = 0;
                    foreach (Books item in bookList)
                    {
                        if (item.Id == askId)
                        {
                            subIndex = bookList.IndexOf(item);

                        }
                    }
                    Console.WriteLine(bookList[subIndex].descriptionOfBook);
                    break;

                case 5:
                    Console.WriteLine("Display the book with particular Id");
                    int askId1 = int.Parse(Console.ReadLine());
                    int subIndex1 = 0;
                    foreach (Books item in bookList)
                    {
                        if (item.Id == askId1)
                        {
                            subIndex1 = bookList.IndexOf(item);
                            break;
                        }
                        
                        /*else
                        {
               
                            Console.WriteLine("Not Found");
                         
                        }
                        */
                    }
                    Console.WriteLine(bookList[subIndex1]);
                    break;
            }
            Console.ReadLine();
        }

    }

}
