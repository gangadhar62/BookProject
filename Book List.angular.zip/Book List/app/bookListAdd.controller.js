myApp.controller("bookListAddController",function($scope){

    $scope.newBook={};

    $scope.saveDetailsEventHandler=function()

    {

        console.log("book details : ",$scope.newBook);

        $scope.$emit("Addnewbook",$scope.newBook)

        $scope.newBook={};

             

    }   

    $scope.cancelAddBookEventHandler=function(){

        $scope.$emit("cancelAddnewBook");

        $scope.newBook={};

    }
});