myApp.controller("bookDisplayController",function($scope){

    $scope.content="Book Details";

    $scope.bookArr=[

    {BookId:1020,BookName:"TWILIGHT",image:'D:\Twilight.jpg',Author:"STEPHENIE MEYER",

    Description:"Twilight eleventh birthday. When the abusive Dursleys refuse to allow jack to open any, Hagrid arrives to personally deliver Harry's letter.",price:1000,ISBN: "123456"},

    {BookId:1021,BookName:"NEW MOON",image:"D:\Newmoon.jpg",Author:"STEPHENIE MEYER",

    Description:"Newmoon  a house-elf who warns him that it is too dangerous to return to Hogwarts. Dobby sabotages an important dinner for the Dursleys.",price:3000,ISBN: "789012"},

    {BookId:1022,BookName:"ECLIPSE",image:"D:\Eclipse.jpg",Author:"STEPHENIE MEYER",

    Description:"Eclipse loses his temper and inadvertently causes Aunt Marge Dursley to inflate like a balloon and float away when the Knight Bus arrives and takes jack to the Leaky Cauldron, outside of Hogwarts.",price:2200,ISBN: "345678"},

    {BookId:1023,BookName:"BREAKING DAWN 1",image:"D:\Breakingdawn 1.jpg",Author:"STEPHENIE MEYER",

    Description:"breaking dawn has a nightmare overhearing Lord Voldemort conspiring with Peter Pettigrew and another man.During which Death Eaters terrorise the camp. The same man who appeared in Jack's dream conjures the Dark Mark.",price:3500,ISBN: "234568"},
    
    {BookId:1024,BookName:"BREAKING DAWN 2",image:"D:\Breakingdawn 2.jpg",Author:"STEPHENIE MEYER",

    Description:"breaking dawn extended part has a nightmare wherein a Muggle caretaker named Frank Bryce is killed after overhearing Lord Voldemort.Jack attends the Quidditch World Cup with the Weasleys and Hermione, during which Death Eaters terrorise the camp.",price:5000,ISBN: "123098"}];

    $scope.selectedBook={};

    $scope.showEditBook=false;

    

    $scope.editedBookDetails=function(obj){

        $scope.selectedBook=obj;

        alert("U have selected BookId :"+ obj.BookId + " to edit");

        $scope.showEditBook=true;

    }
    $scope.showAddBook=false;

    $scope.AddNewBookEventHandler=function()

    {
        $scope.showAddBook=true;
    }
    $scope.$on("Addnewbook",function(event,newBook){

        console.log(newBook);

        $scope.bookArr.push(newBook); 

        $scope.showAddBook=false; 

    }) 

    $scope.$on("cancelAddnewBook",function(){

        $scope.showAddBook=false;

    })
    $scope.deleteBookDetails=function(bookToBeDeleted)

    {

        var pos=$scope.bookArr.findIndex(item=> {

            if(item.BookId == bookToBeDeleted.BookId)

            {

                return true;

            }

            else

            {

                return false;

            }

        })

        $scope.bookArr.splice(pos,1);

        console.log(bookToBeDeleted);

    }

    

    $scope.saveEditDetails = function()

    {

        $scope.showEditBook=false;

    }

})